"""Module containing all covid19 news handling.

news_API_request: Request news articles using newsAPI.
update_news: Store news articles in a list of dictionaries.
"""
import logging
import json
import requests

from newsapi import NewsApiClient

news = []

logging.basicConfig(filename='sys.log', encoding='utf-8', level=logging.DEBUG)

def news_API_request(covid_terms:str = "Covid COVID-19 coronavirus") -> dict:
    """Request news articles containing covid terms in the title from the newsAPI.

    Take a string containing covid19 terms as an argument
    and request articles containing these terms in the title
    from the newsAPI and return the response as a dictionary.
    """
    f = open("config.json")
    api_key = json.load(f)
    api_key = api_key["api_key"]
    if api_key == "enter API key":
        logging.warning("No API key given")
        raise Exception("No API key given in config.json file")
    response = requests.get('https://newsapi.org/v2/everything?qInTitle='
    +covid_terms+'&apiKey='+api_key)
    response_json = response.json()
    return response_json

def update_news(name = 'test') -> list[dict]:
    """Process response from news_API_request and return articles.

    Process the response from the news_API_request and
    store and return as a list of dictionaries containing the title
    and content of each article."""
    response_json = news_API_request()
    news_articles = response_json['articles']
    for article in news_articles:
        news.append({
            'title': article['title'],
            'content': article['description']
        })
    return news
