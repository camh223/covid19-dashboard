"""
Module containing all Covid-19 data handling.

parse_csv_data: Import csv file as a list of strings.
data_is_numeric: Search through data until a numeric entry is found.
process_covid_csv_data: Calculate and return values for each covid data metric.
covid_API_request: Request and return covid data from covid19 API.
total_finder: Find the most recent valid entry for covid data metric.
infection_rate_7day: Calculate the total infections in the past 7 days.
process_covid_json_data: Calculate and return values for each covid data metric.
update_covid: Updates covid data and stores in dictionary.
update_interval_calculator: Calculates time between current and scheduled time.
remove_completed_update: Removes update once scheduled time has been reached.
schedule_covid_updates: Schedules updates to covid data.
fetch_news: Obtains list of news articles.
schedule_news_updates: Schedules updates to news articles.
remove_toast: Removes article from list of news articles.
load_template: Initialises html template and functionality.
"""

import sched
import time
import logging

from uk_covid19 import Cov19API
from flask import Flask, render_template, request

import covid_news_handling
import time_conversions

update_news = covid_news_handling.update_news
s = sched.scheduler(time.time, time.sleep)
hhmm_to_seconds = time_conversions.hhmm_to_seconds

app = Flask(__name__)

processed_data={}
covid_updates = []
cancelled = {}
news = {}

logging.basicConfig(filename='sys.log', encoding='utf-8', level=logging.DEBUG)

def parse_csv_data(csv_filename: str) -> list[str]:
    """Import a csv file containing covid data and return the contents as a list of strings.

    Take a string containing the name of a csv file as an argument
    and opens the file, returning the contents as a list of strings
    called "covid_csv_data".
    """
    lines = open(csv_filename, "r").readlines()
    covid_csv_data = []
    for line in lines:
        covid_csv_data.append(line.strip())
    return covid_csv_data

def data_is_numeric(data_index: int, covid_csv_data: list[str]) -> int:
    """Search through covid_csv_data and return the index of the first numeric data entry.

    Take an integer containing the index of a particular covid
    data metric and a list of strings containing covid_csv_data
    as arguments and find the first numeric entry of this metric.
    Return the index of this entry.
    """
    count = 0
    flag = False
    while not flag:
        day_data = (covid_csv_data[count]).split(",")
        flag = day_data[data_index].isnumeric()
        if not flag:
            count += 1
    return count

def process_covid_csv_data(covid_csv_data: list[str]) -> tuple[int, int, int]:
    """Process covid csv data and return each data metric as an integer.

    Take a list of strings containing covid_csv_data as an argument
    and process the data to find values for the number of infections
    in the last 7 days, the current number of hospital cases, and the
    current total number of deaths, returning each value as an integer.
    """
    cumul_cases = 0
    count = data_is_numeric(6, covid_csv_data)
    for item in range(count + 1, count + 8):
        day_data = (covid_csv_data[item]).split(",")
        day_data[6] = int(day_data[6])
        cumul_cases += day_data[6]
    last7days_cases = cumul_cases
    count = data_is_numeric(5, covid_csv_data)
    day_data = (covid_csv_data[count]).split(",")
    current_hospital_cases = int(day_data[5])
    count = data_is_numeric(4, covid_csv_data)
    day_data = (covid_csv_data[count]).split(",")
    total_deaths = int(day_data[4])
    return(last7days_cases, current_hospital_cases, total_deaths)

def covid_API_request(location:str = 'Exeter', location_type:str = 'ltla') -> list[dict]:
    """Request covid data from the covid19 API and return the data
    as a list of dictionaries.

    Take strings containing the location and location type of the
    area which data is being requested of as arguments. Request data
    using the covid19 API, store and return data as a list of
    dictionaries.
    """

    england_only = [
    'areaType='+location_type,
    'areaName='+location
    ]

    cases_and_deaths = {
        "areaCode": "areaCode",
        "areaName": "areaName",
        "areaType": "areaType",
        "date": "date",
        "cumDeaths28DaysByDeathDate": "cumDeaths28DaysByDeathDate",
        "hospitalCases": "hospitalCases",
        "newCasesBySpecimenDate": "newCasesBySpecimenDate",
        "newCasesByPublishDate": "newCasesByPublishDate"
    }

    api = Cov19API(filters=england_only, structure=cases_and_deaths)

    json_data = api.get_json()
    return json_data

def total_finder(json_data: dict, metric: str) -> int:
    """Search covid data for most recent update of a metric and return an integer.

    Take a list of dictionaries containing covid19 data and
    a string containing the required data metric as arguments.
    Find the most recent complete entry for this metric and
    return the value as an integer."""
    covid_data = json_data['data']
    for day_data in covid_data:
        if type(day_data[metric]) == int:
            break
    return day_data[metric]

def infection_rate_7day(json_data: dict) -> int:
    """Calculate the total number of infections in the last 7 days.

    Take a list of dictionaries contain covid19 data as
    an argument and total the number of cases in the last
    seven days, returning the value as an integer.
    """
    covid_data = json_data['data']
    cumul_cases = 0
    count = 0
    for day_data in covid_data:
        if type(day_data['newCasesByPublishDate']) == int:
            break
        count += 1
    count += 1
    for item in range(count, count + 6):
        day_data = covid_data[item]
        cumul_cases += day_data['newCasesByPublishDate']
    return cumul_cases

def process_covid_json_data(local_area:str = 'Exeter', local_area_type:str = 'ltla',
    nation:str = 'England') -> tuple[str, str, str, str]:
    """Process covid json data and calculat values for each data metric.

    Take strings containing the local area and local area type of the location
    which data is being calculated for, and calculating values for
    the number of cases in the last 7 days locally and nationally, the
    current number of hospital cases, and the total number of deaths. Return
    the value for each metric as a string.
    """
    #Converted to strings for concatenation later
    local_last7days_cases = str(infection_rate_7day(covid_API_request(local_area, local_area_type)))
    nation_last7days_cases = str(infection_rate_7day(covid_API_request(nation, 'nation')))
    current_hospital_cases = str(total_finder(covid_API_request(nation, 'nation'), 'hospitalCases'))
    total_deaths= str(total_finder(covid_API_request(nation,'nation'),'cumDeaths28DaysByDeathDate'))
    return(local_last7days_cases, nation_last7days_cases, current_hospital_cases, total_deaths)

def update_covid(update_name: str):
    """Update covid19 data and store in dictionary.

    Take a string containing the name of an update as an argument.
    If the update has not been cancelled, update the covid data
    using the process_covid_json_data() function and store in
    a dictionary.
    """
    if cancelled.get(update_name) != "Cancelled":
        logging.info("Covid data updated")
        local_last7days_cases,nation_last7days_cases,hospital_cases,deaths=process_covid_json_data()
        processed_data["local_cases"] = local_last7days_cases
        processed_data["national_cases"] = nation_last7days_cases
        processed_data["hospital_cases"] = hospital_cases
        processed_data["deaths"] = deaths
    else:
        logging.info("Data not updated due to cancellation")

def update_interval_calculator(time_interval: str) -> int:
    """Calculate the number of seconds between the current time and the schedule time.

    Take a string containing the time for a scheduled update and
    calculate the number of seconds until that scheduled time
    will be reached, returning the value as an integer.
    """
    target_time = hhmm_to_seconds(time_interval)
    current_time = str(time.gmtime().tm_hour) + ":" + str(time.gmtime().tm_min)
    current_time_converted = hhmm_to_seconds(current_time)
    update_interval = target_time - current_time_converted
    return update_interval

def remove_completed_update(update_name: str):
    """Remove update dictionary containing update_name from covid_updates list.

    Take a string containing the name of an update as an argument,
    and remove the corresponding update from a list of dictionaries
    containing covid updates.
    """
    logging.info("Update"+update_name+"removed")
    for update in covid_updates:
        if update["title"] == update_name:
            covid_updates.remove(update)
            break

def schedule_covid_updates(update_interval: str, update_name: str, repeat:bool = False):
    logging.info("Data update scheduled")
    """Schedule updates to covid19 data at a particular time.

    Take strings containing the time for an update and the name of an update,
    as well as the boolean value "repeat" as arguments. Schedule an update
    to covid data at the update time and and the update name and time to a list
    of dictionaries containing covid updates. If repeat is true, schedule the
    update to repeat every 24 hours. If repeat is false, remove the update from
    the updates list once it has been completed.
    """
    s.enter(update_interval, 1, update_covid, (update_name,))
    if repeat:
        #86400 seconds = 24 hours
        s.enter(86400, 3, schedule_covid_updates, (update_interval, update_name, True,))
    else:
        s.enter(update_interval, 2, remove_completed_update, (update_name,))

def fetch_news(update_name: str):
    """Fetch the news from update_news() function and assign it to global news

    Take a string containing the name of an update as an argument.
    If the update has not been cancelled, fetch up to date news
    articles using the update_news() function in the covid_news_handling
    module and assign the articles to a list of dictionaries containing
    the title and content of the article.
    """
    if cancelled.get(update_name) != "Cancelled":
        logging.info("News fetched")
        global news
        news = update_news()
    else:
        logging.info("News not fetched due to cancellation")

def schedule_news_updates(update_interval: str, update_name: str, repeat:bool = False):
    """Schedule updates to the news articles at a specified time.

    Take strings containing the time for an update and the name of an update,
    as well as the boolean value "repeat" as arguments. Schedule an update
    to news articles at the update time and add the update name and time to a list
    of dictionaries containing covid updates. If repeat is true, schedule the
    update to repeat every 24 hours. If repeat is false, remove the update from
    the updates list once it has been completed.
    """
    logging.info("News update scheduled")
    s.enter(update_interval, 1, fetch_news, (update_name,))
    if repeat:
        #86400 seconds = 24 hours
        s.enter(86400,schedule_news_updates,(update_interval,update_name, True,))
    else:
        s.enter(update_interval, 2, remove_completed_update, (update_name,))

def remove_toast(article_name: str) -> list[dict]:
    """Remove article dictionary containing article_name from news list

    Take a string containing the name of an article as an argument
    and remove the corresponding article from a list of dictionaries
    containing articles, returning the updated list.
    """
    logging.info("Article"+article_name+"removed")
    for article in news:
        if article['title'] == article_name:
            news.remove(article)
            break
    return news

@app.route('/index')
def load_template(local_area:str = 'Exeter', nation:str = 'England') -> str:
    """Initialise the covid dashboard html template and process any inputs.

    Take strings containing the local area and nation as arguments
    and generate the html template for the covid dashboard displaying
    covid data for these regions as well as any news articles relating to
    covid19. Take inputs from the html interface and use them to
    handle any interface functionality. Return a string containing
    information about the template which the Flask module will use
    to render the html template.
    """
    logging.info("Template loaded")
    s.run(blocking = False)
    global news
    if len(news) == 0:
        news = {}
    if len(processed_data) == 0:
        update_covid("First time startup")
    update_name = request.args.get('two')
    update_interval = request.args.get('update')
    repeat_ticked = request.args.get('repeat')
    covid_ticked = request.args.get('covid-data')
    news_ticked = request.args.get('news')
    remove_article = request.args.get('notif')
    remove_update = request.args.get('update_item')
    repeat = False
    if update_name:
        if repeat_ticked == 'repeat':
            repeat = True
        if covid_ticked == 'covid-data':
            covid_updates.append({
                "title": update_name,
                "content": update_interval
            })
            schedule_covid_updates(update_interval_calculator(update_interval), update_name, repeat)
        elif news_ticked == 'news':
            covid_updates.append({
                "title": update_name,
                "content": update_interval
            })
            schedule_news_updates(update_interval_calculator(update_interval), update_name, repeat)
        else:
            logging.warning("No checkbox ticked")
            raise Exception("Text field entry given with no update type ticked.")
    if remove_article:
        news = remove_toast(remove_article)
    if remove_update:
        cancelled[remove_update] = "Cancelled"
        for update in covid_updates:
            if update["title"] == remove_update:
                covid_updates.remove(update)
                break
    return render_template('index.html',
        title ='Covid-19 Dashboard',
        location = local_area,
        local_7day_infections = processed_data['local_cases'],
        nation_location = nation,
        national_7day_infections = processed_data['national_cases'],
        hospital_cases = 'Hospital Cases: '+processed_data['hospital_cases'],
        deaths_total = 'Deaths: '+processed_data['deaths'],
        updates = covid_updates,
        news_articles = news)

if __name__ == '__main__':
    app.run()
