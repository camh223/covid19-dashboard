from covid_data_handler import parse_csv_data
from covid_data_handler import process_covid_csv_data
from covid_data_handler import covid_API_request
from covid_data_handler import schedule_covid_updates
from covid_data_handler import update_interval_calculator
from covid_data_handler import data_is_numeric
from covid_data_handler import infection_rate_7day
from covid_data_handler import process_covid_json_data

import time_conversions
import time

hhmm_to_seconds = time_conversions.hhmm_to_seconds

def test_parse_csv_data():
    data = parse_csv_data('nation_2021-10-28.csv')
    assert len(data) == 639

def test_data_is_numeric():
    data = data_is_numeric(6, parse_csv_data('nation_2021-10-28.csv'))
    assert data == 2

def test_process_covid_csv_data():
    last7days_cases , current_hospital_cases , total_deaths = \
        process_covid_csv_data ( parse_csv_data (
            'nation_2021-10-28.csv' ) )
    assert last7days_cases == 240_299
    assert current_hospital_cases == 7_019
    assert total_deaths == 141_544

def test_covid_API_request():
    data = covid_API_request()
    assert isinstance(data, dict)
    
def test_infection_rate_7day():
    json_data = covid_API_request()
    data = infection_rate_7day(json_data)
    assert isinstance(data, int)

def test_process_covid_json_data():
    data = process_covid_json_data()
    assert isinstance(data, tuple)

def test_schedule_covid_updates():
    schedule_covid_updates(update_interval=10, update_name='update test')
 
def test_update_interval_calculator():
    current_time = str(time.gmtime().tm_hour) + ":" + str(time.gmtime().tm_min)
    current_time_in_s = hhmm_to_seconds(current_time)
    test_update_interval = 36000 - current_time_in_s
    update_interval = update_interval_calculator("10:00")
    assert update_interval == test_update_interval

test_parse_csv_data()
test_data_is_numeric()
test_process_covid_csv_data()
test_covid_API_request()
test_infection_rate_7day()
test_process_covid_json_data()
test_schedule_covid_updates()
test_update_interval_calculator()

from covid_news_handling import news_API_request
from covid_news_handling import update_news

def test_news_API_request():
    assert news_API_request()
    assert news_API_request('Covid COVID-19 coronavirus') == news_API_request()

def test_update_news():
    update_news('test')

test_news_API_request()
test_update_news()
