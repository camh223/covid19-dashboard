Introduction:
The purpose of this project is to provide the user with access to up-to-date covid-19 data and news and the ability to interact
with how this data is presented to them.

Prerequisites:
This project was developed using Python version 3.9.9.
The dependencies needed for this application are the uk-covid19, Flask, and newsapi-python modules.

Installation:
To install dependencies, enter the following into the command prompt:
pip install uk-covid19
pip install Flask
pip install newsapi-python

Getting started:
Go to https://newsapi.org/ and obtain an API key.
Edit the config.json file provided in the package directory and replace enter API key with your api key.
Navigate to the directory containing the covid_data_handler.py python module in the command prompt.
Enter "python covid_data_handler.py" into the command prompt. This will run the program.
Enter http://127.0.0.1:5000/index into the URL bar in a web browser. This will provide the user access to the user interface.

Testing:
The code can be tested using the pytest.py module in the package directory provided.
Navigate to the package directory in the command line and enter: python pytest.py.
Any failed tests will return an assertion error in the command line.
If nothing is returned to the command line, the application has passed all the tests.

Detailed Documentation:
Open the user interface in a web browser using the instructions in the "Getting started" section.
In order to schedule updates to the covid19 data, select the time that you wish the update to occur using the time entry bar,
enter a name for the update in the text box, check the "Update Covid data" checkbox, and click Submit.
In order to schedule updates to the covid19 news articles, select the time that you wish the update to occur using the time entry bar,
enter a name for the update in the text box, check the "Update news articles" checkbox, and click Submit.
If you would like the update to repeat every 24 hours, additionally check the "Repeat update" checkbox before clicking Submit.
Once an update has been scheduled, it will appear underneath the "Scheduled updates" header.
If you would like to cancel the update, click the "x" at the top right of the update. It will then be removed.
Once a news update is triggered, news articles will appear underneath the "News headlines" header. In order to remove an article,
click the "x" at the the top right of the article. It will then be removed.

Details:
Author: Cameron Hallett, camhallett2204@gmail.com
License: MIT
GitHub: https://github.com/camh223/covid19-dashboard
